<#
.DESCRIPTION
Tests the Get-Drives module import.
#>

# Begin Program Flow
Import-Module $PSFramework

Write-Output "Testing Get-Drives module..."
Get-Command -Module PoshSecFramework
#End Program