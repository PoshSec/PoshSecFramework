<#
.DESCRIPTION
Tests the Get-Drives module import.
#>

Write-Output "Testing Get-Drives module..."
Get-Command -Module PoshSecFramework
#End Program