<#
.DESCRIPTION
Tests the import function for the PoshSec Framework.

AUTHOR
Ben0xA
#>

# Begin Script Flow
Import-Module $PSFramework

Write-Output "Hello World!"
#End Script