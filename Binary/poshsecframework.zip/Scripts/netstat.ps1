<#
.DESCRIPTION
This script is for testing the netstat object.

.FRAMEWORK
PoshSec Framework

.FRAMEWORKVERSION
0.2.0.0

.AUTHOR
Ben0xA
#>

# Begin Script Flow
Import-Module $PSFramework

Get-SecOpenPorts

#End Script