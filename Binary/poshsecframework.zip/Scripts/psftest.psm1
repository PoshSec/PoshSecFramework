<#
.DESCRIPTION
Tests the Get-Drives module import.
#>

# Begin Program Flow
Write-Output "Testing Get-Drives module..."
Get-Command -Module PoshSecFramework
#End Program