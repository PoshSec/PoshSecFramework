function Compare-SecOpenPort
{

   <#
    .Synopsis
    Compares a reference object from Get-SecOpenPorts to a difference object from Get-SecOpenPorts
    
    .Description
        Custom compare function that will compare a reference object to a difference object
        
        CSIS 20 Critical Security Controls for Effective Cyber Defense excerpt:
    	Limitation and control of network ports, protocols and services
    
    .Link
        https://github.com/organizations/PoshSec
    #>

    Param(
        [Parameter(Mandatory=$true,Position=1)]
        [string]$ReferenceObject,
        
        [Parameter(Mandatory=$true,Position=2)]
        [string]$DifferenceObject,
        
        [Parameter(Mandatory=$false,Position=3)]
        [boolean]$IncludeEquals
    )
    
    Write-Output $IncludeEquals
}
