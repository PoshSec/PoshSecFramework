Get-ChildItem $PSScriptRoot | ? { $_.PSIsContainer -and $_.Name -ne "PoshSec.PowerShell.Commands" -and $_.Name -ne "PoshSec.PowerShell.Commands 3.5" } | % { Import-Module $_.FullName }

#Commenting this out for now.
#It's causing too many systems not to load the file.
#if ($PSVersionTable.PSVersion.Major -gt 2) {
#    Import-Module $PSScriptRoot\PoshSec.PowerShell.Commands\PoshSec.PowerShell.Commands.dll
#} else {
#    Import-Module $PSScriptRoot\PoshSec.PowerShell.Commands 3.5\PoshSec.PowerShell.Commands.dll
#}

#List Custom Modules Here
Import-Module $PSModRoot\getdrives.psm1