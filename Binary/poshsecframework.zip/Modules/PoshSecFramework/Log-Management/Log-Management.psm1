﻿. (Join-Path $PSScriptRoot Get-SecDNSLogStatus.ps1)
. (Join-Path $PSScriptRoot Get-SecWAPS.ps1)
. (Join-Path $PSScriptRoot Set-SecLogSettings.ps1)