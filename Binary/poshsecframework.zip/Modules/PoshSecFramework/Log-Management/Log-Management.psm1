﻿. (Join-Path $PSScriptRoot Get-SecDNSLogStatus.ps1)
. (Join-Path $PSScriptRoot Get-SecWAP.ps1)
. (Join-Path $PSScriptRoot Set-SecLogSettings.ps1)
. (Join-Path $PSScriptRoot Get-SecIISLog.ps1)
