﻿// <copyright file="CompareTcpConnection.cs" company="PoshSec (https://github.com/PoshSec/)">
//     Copyright © 2013 and distributed under the BSD license.
//     Written by: Ben0xA
// </copyright>

namespace PoshSec.PowerShell.Commands
{
    using System;
    using System.Management.Automation;
    using Microsoft.PowerShell.Commands;
    using System.Net.NetworkInformation;

    /// <summary>
    /// Compares two SystemTCPConnectionInformation objects.
    /// </summary>
   [System.Management.Automation.Cmdlet("Compare", PoshSec.PowerShell.Nouns.TcpConnection)]
    public class TcpConnection : System.Management.Automation.PSCmdlet
    {
        /// <summary>
        /// The reference object to compare to the difference object.
        /// </summary>
        [Parameter(Position = 0, Mandatory = true)]
       public Object ReferenceObject { get; set; }

        /// <summary>
        /// The difference object to compare to the reference object.
        /// </summary>
        [Parameter(Position = 1, Mandatory = true)]
        public Object DifferenceObject { get; set; }

        protected override void ProcessRecord()
        {
            this.WriteObject("It worked.");
        }
    }
}
