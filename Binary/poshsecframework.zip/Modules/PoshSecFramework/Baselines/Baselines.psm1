﻿. (Join-Path $PSScriptRoot Start-SecBaseline.ps1)
. (Join-Path $PSScriptRoot Start-SecDailyFunction.ps1)