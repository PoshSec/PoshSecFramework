﻿. (Join-Path $PSScriptRoot Start-SecBaselines.ps1)
. (Join-Path $PSScriptRoot Start-SecDailyFunctions.ps1)