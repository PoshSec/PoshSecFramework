﻿. (Join-Path $PSScriptRoot Compare-SecDeviceInventory.ps1)
. (Join-Path $PSScriptRoot Get-SecDeviceInventory.ps1)
. (Join-Path $PSScriptRoot Get-SecConnectivity.ps1)